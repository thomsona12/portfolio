describe('expense generator test', () => {
    it('visits the root', () => {
    cy.visit('/');
    });
    it('clicks the menu button expenses option', () => {
    cy.get('mat-icon').click();
    cy.contains('a', 'generator').click();
    });
    it('selects an vendor', () => {
    cy.wait(500);
    cy.get('mat-select[formcontrolname="vendorid"]').click();
    cy.contains('Andrews').click();
    });
    it('selects an Product', () => {
    cy.wait(500);
    cy.get('mat-select[formcontrolname="productid"]').click();
    cy.contains('Bear').click();
    });
    it('selects an Qunatity', () => {
        cy.wait(500);
        cy.get('mat-select[formcontrolname="quantity"]').click();
        cy.contains('eoq').click();
        });
    it('clicks the save button', () => {
    cy.get('button').contains('Save PurchaseOrder').click();
    });
    it('confirms purchase order added', () => {
    cy.contains('added!');
    });
   });
   
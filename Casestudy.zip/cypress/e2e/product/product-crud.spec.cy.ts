import './product-add.spec.cy.ts';
import './product-update.spec.cy.ts';
import './product-delete.spec.cy.ts';
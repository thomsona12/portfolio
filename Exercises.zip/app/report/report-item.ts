/**
* ReportItem - container class for expense report item
*/
export interface ReportItem {
    id: number;
    reportid: number;
    expenseid: number;
   }
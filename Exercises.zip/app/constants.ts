export const BASEURL = 'http://localhost:8080/api/';
export const PDFURL = 'http://localhost:8080/ReportPDF?repid=';